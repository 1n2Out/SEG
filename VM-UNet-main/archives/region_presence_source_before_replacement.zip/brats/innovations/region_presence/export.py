"""Export a direction-two checkpoint for inference with unmodified VMUNet.

Usage: python -m brats.innovations.region_presence.export --checkpoint RUN/best.pth
       --output results/exports/experiment_inference.pth
"""
import argparse
from collections import OrderedDict
from pathlib import Path

from . import resolve_settings


def inference_checkpoint(checkpoint, source):
    settings = resolve_settings(checkpoint["config"].get("region_presence", {}))
    if settings["mode"] == "off":
        raise ValueError("Expected an enabled region_presence experiment checkpoint")
    config = dict(checkpoint["config"])
    del config["region_presence"]
    state = OrderedDict((key, value) for key, value in checkpoint["model_state_dict"].items()
                        if not key.startswith("presence_head."))
    if any(not key.startswith("vmunet.") for key in state):
        raise ValueError("Unexpected model keys; export only supports plain PresenceVMUNet/VMUNet checkpoints")
    return {"epoch": checkpoint["epoch"], "config": config,
            "manifest_sha256": checkpoint["manifest_sha256"], "model_state_dict": state,
            "evaluation_only": True,
            "export_provenance": {"source_checkpoint": str(source), "region_presence": settings,
                                  "note": "Auxiliary head and optimizer removed; segmentation weights unchanged"}}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    from train_brats import load_checkpoint
    import torch
    source, output = args.checkpoint.resolve(), args.output.resolve()
    if source == output or output.exists():
        parser.error("Output must be a new file; original checkpoints are never overwritten")
    exported = inference_checkpoint(load_checkpoint(source), source)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("xb") as stream:
        torch.save(exported, stream)
    print("Exported inference-only checkpoint:", output)


if __name__ == "__main__":
    main()
