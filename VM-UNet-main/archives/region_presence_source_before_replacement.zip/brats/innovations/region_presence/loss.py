"""Positive-region Dice + absent-region hard negatives, with optional presence BCE."""
import math

import torch
import torch.distributed as dist
import torch.nn.functional as F
from torch import nn

from brats.losses import BraTSCEDiceLoss
from . import resolve_settings


REGION_LABELS = ((1, 2, 3), (1, 3), (3,))  # training labels, in WT/TC/ET order


def region_targets(target):
    return torch.stack((target != 0, (target == 1) | (target == 3), target == 3), dim=1)


def grouped_means(sums, counts):
    """Global positive/negative group means, including DDP gradient scaling.

DDP averages parameter gradients, so local differentiable sums are multiplied
by world_size / global_count. The detached correction reports the true global
scalar on every rank. Empty groups contribute differentiable zero. Only one
small collective is needed for all regions/groups in each training step.
"""
    if not (dist.is_available() and dist.is_initialized()):
        return sums / counts.clamp_min(1)
    stats = torch.cat((sums.detach(), counts.detach())).clone()
    dist.all_reduce(stats)
    global_sums, global_counts = stats.chunk(2)
    denominator = global_counts.clamp_min(1)
    gradient_term = sums * dist.get_world_size() / denominator
    return gradient_term + (global_sums / denominator - gradient_term.detach())


class RegionPresenceLoss(nn.Module):
    def __init__(self, settings):
        super().__init__()
        self.settings = resolve_settings(settings)
        mode = self.settings["mode"]
        if mode == "off":
            raise ValueError("Use the original BraTSCEDiceLoss for off mode")
        self.with_head = mode in ("head_only", "full")
        self.conditional = mode in ("loss_only", "full")
        self.baseline = BraTSCEDiceLoss()
        self.component_names = ("ce", "dice")
        if self.conditional:
            self.component_names += ("empty_fp",)
        if self.with_head:
            self.component_names += ("presence",)

    def forward(self, output, target, return_components=False):
        logits = output["logits"] if isinstance(output, dict) else output
        if logits.ndim != 4 or logits.shape[1] != 4 or target.shape != logits.shape[:1] + logits.shape[2:]:
            raise ValueError("Expected logits B,4,H,W and target B,H,W")
        logits = logits.float()  # reductions and log-probabilities stay FP32 under AMP
        truth = region_targets(target)
        present = truth.flatten(2).any(dim=2)
        if self.conditional:
            probabilities = logits.softmax(dim=1)
            regions = torch.stack([probabilities[:, labels].sum(dim=1) for labels in REGION_LABELS], dim=1)
            truth_float = truth.float()
            dice = 1 - (2 * (regions * truth_float).sum(dim=(2, 3)) + 1e-5) / (
                regions.sum(dim=(2, 3)) + truth_float.sum(dim=(2, 3)) + 1e-5)
            # -log(1-p_region) computed through logsumexp, avoiding probability
            # clamping/saturation even for extreme wrong foreground confidence.
            log_normalizer = logits.logsumexp(dim=1)
            negative_maps = torch.stack([
                log_normalizer - logits[:, [label for label in range(4) if label not in labels]].logsumexp(dim=1)
                for labels in REGION_LABELS
            ], dim=1)
            count = math.ceil(self.settings["topk_fraction"] * target.shape[-2] * target.shape[-1])
            negative = negative_maps.flatten(2).topk(count, dim=2, sorted=False).values.mean(dim=2)
            positive_mask, negative_mask = present.float(), (~present).float()
            sums = torch.cat(((dice * positive_mask).sum(dim=0), (negative * negative_mask).sum(dim=0)))
            counts = torch.cat((positive_mask.sum(dim=0), negative_mask.sum(dim=0)))
            positive_means, negative_means = grouped_means(sums, counts).chunk(2)
            ce = F.cross_entropy(logits, target.long())
            dice_loss, empty_fp = positive_means.mean(), negative_means.mean()
            total = ce + dice_loss + self.settings["negative_weight"] * empty_fp
            components = {"ce": ce.detach(), "dice": dice_loss.detach(), "empty_fp": empty_fp.detach()}
        else:
            total, components = self.baseline(logits, target, return_components=True)
        if self.with_head:
            if not isinstance(output, dict) or "presence_logits" not in output:
                raise ValueError("Presence supervision requires model.train() and presence_logits")
            presence_logits = output["presence_logits"]
            if presence_logits.shape != present.shape:
                raise ValueError("presence_logits must have shape B,3 in WT/TC/ET order")
            presence = F.binary_cross_entropy_with_logits(presence_logits.float(), present.float())
            total = total + self.settings["presence_weight"] * presence
            components["presence"] = presence.detach()
        return (total, components) if return_components else total
