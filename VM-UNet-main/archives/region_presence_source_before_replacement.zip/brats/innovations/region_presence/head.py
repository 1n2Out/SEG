"""Small training-only head; no selective-scan dependency."""
import torch
from torch import nn


class RegionPresenceHead(nn.Module):
    """Predict WT/TC/ET presence from BHWC decoder features."""

    def __init__(self, channels, hidden_channels=64):
        super().__init__()
        self.classifier = nn.Sequential(
            nn.Linear(2 * channels, hidden_channels), nn.GELU(),
            nn.Linear(hidden_channels, 3),
        )

    def forward(self, features):
        pooled = torch.cat((features.mean(dim=(1, 2)), features.amax(dim=(1, 2))), dim=1)
        return self.classifier(pooled)
