"""Direction two: region-presence auxiliary supervision and conditional loss.

Configuration is deliberately torch-free so launcher --dry-run stays lightweight.
Model and loss implementations are imported only when selected.
"""
import math


DEFAULTS = {
    "mode": "off",
    "presence_weight": 0.1,
    "negative_weight": 0.1,
    "topk_fraction": 0.01,
    "hidden_channels": 64,
}
MODES = ("off", "head_only", "loss_only", "full")


def resolve_settings(settings):
    if not isinstance(settings, dict):
        raise ValueError("region_presence must be an object")
    unknown = set(settings) - set(DEFAULTS)
    if unknown:
        raise ValueError("Unknown region_presence settings: " + ", ".join(sorted(unknown)))
    result = {**DEFAULTS, **settings}
    if result["mode"] not in MODES:
        raise ValueError("region_presence.mode must be one of " + ", ".join(MODES))
    for name in ("presence_weight", "negative_weight", "topk_fraction"):
        value = result[name]
        if (isinstance(value, bool) or not isinstance(value, (int, float))
                or not math.isfinite(value) or value <= 0):
            raise ValueError("region_presence." + name + " must be finite and positive; use mode to disable a component")
    if result["topk_fraction"] > 1:
        raise ValueError("region_presence.topk_fraction must be at most 1")
    if type(result["hidden_channels"]) is not int or result["hidden_channels"] < 1:
        raise ValueError("region_presence.hidden_channels must be a positive integer")
    return result
