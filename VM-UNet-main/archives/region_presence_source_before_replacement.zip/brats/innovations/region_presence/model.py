"""VMUNet subclass: preserve all baseline parameter names and pretrained loading."""
import torch

from models.vmunet.vmunet import VMUNet
from . import resolve_settings
from .head import RegionPresenceHead


class PresenceVMUNet(VMUNet):
    def __init__(self, region_presence, **kwargs):
        settings = resolve_settings(region_presence)
        if settings["mode"] not in ("head_only", "full"):
            raise ValueError("PresenceVMUNet requires head_only or full mode")
        super().__init__(**kwargs)
        # Auxiliary initialization must not shift the baseline's subsequent RNG
        # sequence (drop path, training augmentation, etc.). Construction is CPU.
        with torch.random.fork_rng(devices=[]):
            self.presence_head = RegionPresenceHead(self.vmunet.dims[0], settings["hidden_channels"])

    def forward(self, x):
        if not self.training:
            # Exact original inference path: no head, threshold, or hard gating.
            return super().forward(x)
        if x.size(1) != self.input_channels:
            raise ValueError(f"Expected {self.input_channels} input channels, got {x.size(1)}")
        encoded, skips = self.vmunet.forward_features(x)
        decoded = self.vmunet.forward_features_up(encoded, skips)
        return {"logits": self.vmunet.forward_final(decoded),
                "presence_logits": self.presence_head(decoded)}
