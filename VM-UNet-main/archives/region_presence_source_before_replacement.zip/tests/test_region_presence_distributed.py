"""Opt-in real CPU/Gloo DDP check; no substitute selective-scan implementation."""
import os
from datetime import timedelta
from pathlib import Path

import pytest

torch = pytest.importorskip("torch")
import torch.distributed as dist
import torch.multiprocessing as mp
from torch.nn.parallel import DistributedDataParallel
from brats.innovations.region_presence.loss import RegionPresenceLoss


def worker(rank, rendezvous, folder):
    torch.set_num_threads(1)
    dist.init_process_group("gloo", init_method=rendezvous, rank=rank, world_size=2, timeout=timedelta(seconds=60))
    try:
        torch.manual_seed(27)
        model = DistributedDataParallel(torch.nn.Conv2d(1, 4, 1))
        image = torch.full((1, 1, 2, 2), float(rank + 1))
        # Each rank is missing an entire group: naive local averaging is wrong.
        target = torch.full((1, 2, 2), 0 if rank == 0 else 3, dtype=torch.long)
        loss = RegionPresenceLoss({"mode": "loss_only"})(model(image), target)
        loss.backward()
        torch.save({"gradients": [p.grad for p in model.parameters()], "loss": loss.detach()},
                   Path(folder) / (str(rank) + ".pth"))
    finally:
        dist.destroy_process_group()


@pytest.mark.skipif(os.environ.get("BRATS_TEST_DISTRIBUTED") != "1", reason="Set BRATS_TEST_DISTRIBUTED=1 for real two-process Gloo test")
def test_distributed_group_normalization_matches_global_batch(tmp_path):
    mp.spawn(worker, args=((tmp_path / "rendezvous").as_uri(), str(tmp_path)), nprocs=2, join=True)
    torch.manual_seed(27)
    model = torch.nn.Conv2d(1, 4, 1)
    image = torch.stack((torch.ones(1, 2, 2), torch.full((1, 2, 2), 2.0)))
    target = torch.stack((torch.zeros(2, 2, dtype=torch.long), torch.full((2, 2), 3, dtype=torch.long)))
    loss = RegionPresenceLoss({"mode": "loss_only"})(model(image), target)
    loss.backward()
    results = [torch.load(tmp_path / (str(rank) + ".pth"), weights_only=False) for rank in range(2)]
    for result in results:
        for actual, parameter in zip(result["gradients"], model.parameters()):
            torch.testing.assert_close(actual, parameter.grad)
    torch.testing.assert_close(sum(r["loss"] for r in results) / 2, loss.detach())
