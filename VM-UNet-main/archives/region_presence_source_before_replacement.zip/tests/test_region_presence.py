"""Direction-two math, configuration and baseline compatibility; CPU only."""
import copy
import json
import math

import pytest

from brats.innovations.region_presence import resolve_settings
from train_brats import SOURCE, load_training_config, validate_config


@pytest.mark.parametrize("settings", [None, True, {"mode": "typo"}, {"enabled": True},
    {"presence_weight": 0}, {"negative_weight": -1}, {"negative_weight": float("nan")},
    {"topk_fraction": 0}, {"topk_fraction": 1.1}, {"topk_fraction": True},
    {"hidden_channels": 0}, {"hidden_channels": 1.5}, {"hidden_channels": True}])
def test_reject_invalid_settings(settings):
    with pytest.raises(ValueError, match="region_presence"):
        resolve_settings(settings)


def test_experiment_configs_only_change_innovation_and_output_directory():
    baseline = json.loads((SOURCE / "configs/brats2020.json").read_text())
    for mode in ("head_only", "loss_only", "full"):
        path = SOURCE / "configs/region_presence" / (mode + ".json")
        experiment = json.loads(path.read_text())
        assert experiment.pop("region_presence")["mode"] == mode
        assert experiment["launch"]["work_dir"] != baseline["launch"]["work_dir"]
        experiment["launch"]["work_dir"] = baseline["launch"]["work_dir"]
        assert experiment == baseline
        validate_config(load_training_config(path))


def test_resolved_defaults_are_part_of_saved_training_config(tmp_path):
    config = json.loads((SOURCE / "configs/brats2020.json").read_text())
    config["region_presence"] = {"mode": "full"}
    path = tmp_path / "config.json"
    path.write_text(json.dumps(config))
    assert load_training_config(path)["region_presence"] == resolve_settings({"mode": "full"})


torch = pytest.importorskip("torch")
from brats.innovations.region_presence.export import inference_checkpoint
from brats.innovations.region_presence.head import RegionPresenceHead
from brats.innovations.region_presence.loss import RegionPresenceLoss, region_targets
from brats.losses import BraTSCEDiceLoss
from train_brats import build_criterion


def test_off_is_exact_baseline_including_gradients_without_plugin_import(monkeypatch):
    import builtins
    original_import = builtins.__import__

    def guard(name, *args, **kwargs):
        if name.startswith("brats.innovations"):
            pytest.fail("Disabled criterion must not import the plugin")
        return original_import(name, *args, **kwargs)

    monkeypatch.setattr(builtins, "__import__", guard)
    target = torch.randint(0, 4, (2, 8, 8))
    logits = torch.randn(2, 4, 8, 8, requires_grad=True)
    expected, components = BraTSCEDiceLoss()(logits, target, True)
    gradient = torch.autograd.grad(expected, logits)[0]
    for config in ({}, {"region_presence": {"mode": "off"}}):
        criterion = build_criterion(config)
        assert type(criterion) is BraTSCEDiceLoss
        result, actual = criterion(logits, target, True)
        assert torch.equal(result, expected)
        assert all(torch.equal(actual[k], v) for k, v in components.items())
        assert torch.equal(torch.autograd.grad(result, logits)[0], gradient)


def test_region_membership_and_presence_preserve_overlapping_regions():
    target = torch.tensor([[[0]], [[1]], [[2]], [[3]]])
    expected = torch.tensor([[False, False, False], [True, True, False],
                             [True, False, False], [True, True, True]])
    assert torch.equal(region_targets(target).flatten(2).any(2), expected)


def test_conditional_loss_matches_hand_computed_positive_and_empty_groups():
    logits = torch.zeros(2, 4, 2, 2, requires_grad=True)
    target = torch.tensor([[[0, 0], [0, 0]], [[3, 3], [3, 3]]])
    criterion = RegionPresenceLoss({"mode": "loss_only", "negative_weight": 0.2})
    loss, components = criterion(logits, target, True)
    probabilities = (0.75, 0.5, 0.25)
    dice = sum(1 - (8 * p + 1e-5) / (4 * p + 4 + 1e-5) for p in probabilities) / 3
    negative = sum(-math.log(1 - p) for p in probabilities) / 3
    assert components["dice"].item() == pytest.approx(dice, abs=1e-6)
    assert components["empty_fp"].item() == pytest.approx(negative, abs=1e-6)
    assert loss.item() == pytest.approx(math.log(4) + dice + 0.2 * negative, abs=1e-6)
    loss.backward()
    assert torch.isfinite(logits.grad).all()


@pytest.mark.parametrize("fill", [0, 1, 2, 3])
def test_no_positive_or_no_negative_group_has_finite_gradients(fill):
    logits = torch.randn(2, 4, 4, 4, requires_grad=True)
    target = torch.full((2, 4, 4), fill, dtype=torch.long)
    loss, components = RegionPresenceLoss({"mode": "loss_only"})(logits, target, True)
    loss.backward()
    assert torch.isfinite(loss) and torch.isfinite(logits.grad).all()
    if fill == 0:
        assert components["dice"].item() == 0
    if fill == 3:
        assert components["empty_fp"].item() == 0


def test_topk_targets_high_confidence_false_positives_without_log_saturation():
    logits = torch.zeros(1, 4, 2, 2)
    logits[0, 3, 0, 0] = 1000
    logits.requires_grad_()
    target = torch.zeros(1, 2, 2, dtype=torch.long)
    loss, components = RegionPresenceLoss({"mode": "loss_only", "topk_fraction": 0.01})(logits, target, True)
    assert components["empty_fp"].item() > 990
    loss.backward()
    assert torch.isfinite(loss) and torch.isfinite(logits.grad).all()
    assert logits.grad[0, 3, 0, 0] > logits.grad[0, 3, 1, 1]


def test_head_only_keeps_original_dice_and_adds_presence_bce():
    logits = torch.randn(2, 4, 8, 8, requires_grad=True)
    target = torch.randint(0, 4, (2, 8, 8))
    presence = torch.zeros(2, 3, requires_grad=True)
    baseline, expected = BraTSCEDiceLoss()(logits, target, True)
    total, components = RegionPresenceLoss({"mode": "head_only", "presence_weight": 0.3})(
        {"logits": logits, "presence_logits": presence}, target, True)
    assert torch.equal(components["dice"], expected["dice"])
    assert total.item() == pytest.approx(baseline.item() + 0.3 * math.log(2), abs=1e-6)
    total.backward()
    assert torch.isfinite(presence.grad).all() and presence.grad.abs().sum() > 0


def test_full_head_backpropagates_to_decoder_and_components_reconstruct_total():
    features = torch.randn(2, 8, 8, 12, requires_grad=True)
    head = RegionPresenceHead(12, 8)
    logits = torch.randn(2, 4, 8, 8, requires_grad=True)
    target = torch.zeros(2, 8, 8, dtype=torch.long)
    target[1, 2:4, 2:4] = 3
    loss, c = RegionPresenceLoss({"mode": "full"})(
        {"logits": logits, "presence_logits": head(features)}, target, True)
    expected = c["ce"] + c["dice"] + 0.1 * c["empty_fp"] + 0.1 * c["presence"]
    torch.testing.assert_close(loss.detach(), expected)
    loss.backward()
    assert features.grad.abs().sum() > 0
    assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in head.parameters())


def test_missing_presence_output_fails_clearly():
    with pytest.raises(ValueError, match="presence_logits"):
        RegionPresenceLoss({"mode": "head_only"})(torch.zeros(1, 4, 2, 2), torch.zeros(1, 2, 2, dtype=torch.long))


def test_export_removes_only_auxiliary_parameters_and_training_state():
    checkpoint = {"config": {"region_presence": {"mode": "full"}, "seed": 42},
                  "epoch": 55, "manifest_sha256": "fixed-split", "optimizer_state_dict": {},
                  "model_state_dict": {"vmunet.weight": torch.randn(3), "presence_head.weight": torch.randn(2)}}
    before = copy.deepcopy(checkpoint)
    exported = inference_checkpoint(checkpoint, "original.pth")
    assert exported["evaluation_only"]
    assert exported["config"] == {"seed": 42}
    assert exported["manifest_sha256"] == "fixed-split" and exported["epoch"] == 55
    assert list(exported["model_state_dict"]) == ["vmunet.weight"]
    assert torch.equal(exported["model_state_dict"]["vmunet.weight"], before["model_state_dict"]["vmunet.weight"])
    assert "optimizer_state_dict" not in exported
    assert checkpoint["config"] == before["config"]
    assert "presence_head.weight" in checkpoint["model_state_dict"]
