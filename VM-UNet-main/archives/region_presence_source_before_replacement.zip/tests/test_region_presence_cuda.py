"""Real VM-UNet/CUDA integration; skips on hosts without a CUDA driver."""
import json

import pytest

torch = pytest.importorskip("torch")
pytestmark = pytest.mark.skipif(not torch.cuda.is_available(), reason="Real CUDA selective scan required")


def test_real_model_auxiliary_training_checkpoint_and_export(tmp_path):
    from train_brats import SOURCE, build_model, build_criterion, load_checkpoint, save_checkpoint
    from brats.innovations.region_presence.export import inference_checkpoint
    config = json.loads((SOURCE / "configs/brats2020.json").read_text())
    torch.manual_seed(42)
    baseline = build_model(config)
    baseline_rng = torch.get_rng_state().clone()
    settings = {"mode": "full"}
    experimental = {**config, "region_presence": settings}
    torch.manual_seed(42)
    model = build_model(experimental)
    assert torch.equal(baseline_rng, torch.get_rng_state())
    for name, value in baseline.state_dict().items():
        assert torch.equal(value, model.state_dict()[name]), name
    torch.manual_seed(42)
    off_model = build_model({**config, "region_presence": {"mode": "off"}})
    assert type(off_model) is type(baseline)
    assert torch.equal(baseline_rng, torch.get_rng_state())
    del off_model, baseline
    model.cuda().train()
    image = torch.randn(2, 4, 64, 64, device="cuda")
    target = torch.zeros(2, 64, 64, dtype=torch.long, device="cuda")
    target[1, 20:24, 20:24] = 3
    criterion = build_criterion(experimental)
    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-4)
    scaler = torch.cuda.amp.GradScaler()
    with torch.cuda.amp.autocast():
        output = model(image)
        assert output["logits"].shape == (2, 4, 64, 64)
        assert output["presence_logits"].shape == (2, 3)
        loss = criterion(output, target)
    scaler.scale(loss).backward()
    scaler.unscale_(optimizer)
    assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in model.parameters() if p.requires_grad)
    assert model.presence_head.classifier[0].weight.grad.abs().sum() > 0
    scaler.step(optimizer)
    scaler.update()
    optimizer.zero_grad(set_to_none=True)
    checkpoint = {"config": experimental, "epoch": 1, "manifest_sha256": "integration-only",
                  "model_state_dict": model.state_dict(), "optimizer_state_dict": optimizer.state_dict(),
                  "scaler_state_dict": scaler.state_dict()}
    path = tmp_path / "checkpoint.pth"
    save_checkpoint(path, checkpoint)
    saved = load_checkpoint(path)
    resumed = build_model(saved["config"]).cuda()
    resumed.load_state_dict(saved["model_state_dict"], strict=True)
    resumed_optimizer = torch.optim.AdamW(resumed.parameters(), lr=1e-4)
    resumed_optimizer.load_state_dict(saved["optimizer_state_dict"])
    # Same random state and optimizer state must produce the same next update.
    model.train()
    resumed.train()
    for candidate, opt in ((model, optimizer), (resumed, resumed_optimizer)):
        torch.manual_seed(71)
        opt.zero_grad(set_to_none=True)
        next_loss = criterion(candidate(image), target)
        next_loss.backward()
        opt.step()
    for actual, expected in zip(resumed.parameters(), model.parameters()):
        torch.testing.assert_close(actual, expected)
    del resumed, resumed_optimizer
    exported = inference_checkpoint({**checkpoint, "model_state_dict": model.state_dict()}, "original.pth")
    inference = build_model(exported["config"]).cuda().eval()
    inference.load_state_dict(exported["model_state_dict"], strict=True)
    model.eval()

    def fail_head(*args):
        pytest.fail("Presence head must not execute during inference")

    hook = model.presence_head.register_forward_hook(fail_head)
    with torch.no_grad():
        torch.testing.assert_close(model(image), inference(image), rtol=0, atol=0)
    hook.remove()
