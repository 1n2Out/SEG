# 方向二：区域存在性感知监督

这是可选实验实现。默认 `configs/brats2020.json` 保持 baseline；本模块尚无正式实验效果结论。初始权重与 Top-k 比例是实验起点，未经过调优。

## 开关与消融

通过独立配置中的 `region_presence.mode` 控制。省略整个 `region_presence` 字段或设置 `mode: "off"`，使用原 VMUNet 和原 CE + Dice。

| mode | 存在性辅助头 | 分割损失 | 配置 |
| --- | --- | --- | --- |
| `off` / 省略 | 无 | 原 CE + Dice | `configs/brats2020.json` |
| `head_only` | 有 | 原 CE + Dice + 存在性 BCE | `configs/region_presence/head_only.json` |
| `loss_only` | 无 | CE + 非空区域 Dice + 空区域 Top-k 惩罚 | `configs/region_presence/loss_only.json` |
| `full` | 有 | 条件化分割损失 + 存在性 BCE | `configs/region_presence/full.json` |

三个实验配置沿用当前 baseline 的其他训练参数、数据划分与预训练初始化，各自写入独立的结果目录。以下命令在 `VM-UNet-main/` 下使用 `vm_unet` 环境执行。

```bash
# 预览，不启动训练。
python run_brats.py train --config configs/region_presence/full.json --dry-run

# GPU 上先进行短时前后向和单病例验证；不是正式实验结果。
python run_brats.py smoke --config configs/region_presence/full.json

# 正式训练；按需要将 full.json 换成 head_only.json 或 loss_only.json。
python run_brats.py train --config configs/region_presence/full.json --background

# 续跑使用同一份配置和原训练目录。
python run_brats.py resume --config configs/region_presence/full.json --run-dir results/实际训练目录 --background

# 方法确定后再评价测试集。run-dir 指目录，不是 best.pth 文件。
python run_brats.py test --config configs/region_presence/full.json --run-dir results/实际训练目录
```

新增配置字段：

```json
"region_presence": {
  "mode": "full",
  "presence_weight": 0.1,
  "negative_weight": 0.1,
  "topk_fraction": 0.01,
  "hidden_channels": 64
}
```

参数必须为有限正数；`topk_fraction` 不超过 1，`hidden_channels` 为正整数。通过 mode 关闭组件，避免创建不参与优化的辅助参数。未填写的参数在读取配置时补全，完整设置写入 `config.json` 和 checkpoint。恢复训练时仍严格比较配置，不能中途切换模式或权重。

## 实现口径

### 存在性辅助头

使用最后一层 1/4 分辨率解码特征（BHWC，当前 C=96），拼接空间平均池化和最大池化结果，经 `Linear(2C,64) → GELU → Linear(64,3)` 预测 WT、TC、ET 是否存在。

存在标签来自当前切片的真实掩膜，按训练标签 `{1,2,3}`、`{1,3}`、`{3}` 生成。三个标签可同时为真，采用三个独立的 BCEWithLogits，而非互斥分类。均匀平均切片和区域，不引入类别重加权。

训练时模型返回 `logits` 和 `presence_logits`；`model.eval()` 时直接走原 VMUNet 前向，返回四类 logits，不执行辅助头、不进行概率门控或整片清零。主干参数名保留 `vmunet.*`，新增参数只有 `presence_head.*`。辅助头初始化隔离 CPU 随机数状态，不改变相同 seed 下主干的初始化及之后的随机数序列。

### 条件化分割损失

对于每个区域，按切片真值是否非空分为正、负组：

- 正组：计算原形式的逐切片 Soft Dice Loss，先在该区域的非空切片内平均，再对 WT/TC/ET 三个区域等权平均。
- 负组：计算每个像素的 `-log(1 - p_region)`，每张切片取最高的 `ceil(topk_fraction × H × W)` 个值的均值；先在该区域的空切片内平均，再对三个区域等权平均。当前 H×W 包括 256×256 输入的填充区域，至少取一个像素。
- 某组在整个 batch 中为空时，该组贡献可微的零；区域平均的分母固定为 3。保留所有训练切片，没有阴性切片抽样。

联合模式的损失为：

`L = CE + Dice_positive + negative_weight × EmptyFP_topk + presence_weight × PresenceBCE`

`head_only` 完整保留原 CE + Dice 的计算方式；`loss_only` 不创建辅助头。空区域惩罚通过 logits 的 logsumexp 差计算，避免高置信度误检时 `log(1-p)` 的数值饱和；概率、损失归约使用 FP32，兼容 AMP。

DDP 模式按全局 batch 统计各区域正、负组的计数和损失和，修正本地梯度缩放，避免某张卡缺少正/负样本导致分组平均偏差。每步仅为这些分组统计进行一次小型额外 collective。

### 日志与参数统计

`history.jsonl` 保留 `train_loss`、`train_ce_loss`、`train_dice_loss`，按启用的组件额外写入：

- `train_empty_fp_loss`：未乘 `negative_weight` 的空区域惩罚；
- `train_presence_loss`：未乘 `presence_weight` 的存在性 BCE。

`train_loss` 是实际优化的加权总损失。条件化模式的 `train_dice_loss` 仅统计非空组，与 baseline 的全切片 Dice Loss 口径不同，不直接比较其绝对值。现有曲线工具仍显示总损失和 CE/Dice 分量，新增分量保存在 JSONL 中。

保留辅助头的实验模型中，`model_parameters` 包含辅助头，即使评价时辅助头不执行。当前 96 通道、hidden=64 时辅助头为 12,547 个参数。导出去头权重后参数量恢复为分割主干的参数量。

## 文件边界与移除

算法实现全部放在 [region_presence/](../brats/innovations/region_presence/)：

| 文件 | 职责 |
| --- | --- |
| `__init__.py` | 模式、默认值、严格参数校验；不依赖 PyTorch |
| `head.py` | 平均/最大池化存在性头 |
| `model.py` | VMUNet 子类，训练附加输出，评价走原前向 |
| `loss.py` | 区域目标、条件化损失、DDP 分组归一化 |
| `export.py` | 去掉辅助头并导出纯分割推理权重 |

现有源码仅在 `train_brats.py` 接入：可选配置解析/校验、模型和损失选择、通用损失分量记录、smoke 输出适配，以及导出权重的恢复保护。原 `vmunet.py`、`vmamba.py`、`brats/losses.py`、数据和评价代码均未修改。

停用时使用 baseline 配置即可。需要删除实现时：

1. 先保存仍需使用的实验配置与日志；若需要保留实验模型的推理能力，按下节导出去头权重。
2. 使用不含 `region_presence` 字段的 baseline 配置，再删除 `brats/innovations/region_presence/`、`configs/region_presence/` 和 `tests/test_region_presence*.py`。
3. `train_brats.py` 中的可选导入只在配置包含或启用该模块时执行，省略字段的 baseline 可继续运行。若要彻底清理，再移除其中带 `region_presence` 的可选分支；通用的日志和输出处理可保留。

删除模块后，带辅助头的原始训练 checkpoint 不能直接加载到 baseline。正常续跑始终需要原模块及原训练 checkpoint，不能用推理导出文件续跑。

## 导出不依赖创新模块的推理权重

```bash
python -m brats.innovations.region_presence.export \
  --checkpoint results/实际训练目录/best.pth \
  --output results/exports/region_presence_inference.pth
```

导出保留所有分割主干权重、epoch 和患者划分校验值，删除辅助头、优化器等训练状态及配置中的 `region_presence` 字段，保存来源和原创新设置。输出路径必须是新文件；原 checkpoint 不会覆盖。`loss_only` 同样可导出以移除实验配置依赖。

导出文件只能评价或预测，训练入口会明确拒绝用它 resume。它可通过原 `train_brats.py --mode evaluate --checkpoint ...` 加载，无需创新模块。保留原始 checkpoint 可继续进行消融审计与训练恢复。

## 验证

```bash
# CPU 数值、梯度、空组、配置及 baseline 兼容性。
python -m pytest -q tests/test_region_presence.py

# 真实 CUDA selective scan、AMP 前后向、恢复和导出一致性。
CUDA_VISIBLE_DEVICES=2 python -m pytest -q tests/test_region_presence_cuda.py

# 两进程真实 Gloo：分组梯度与单进程全局 batch 一致性。
BRATS_TEST_DISTRIBUTED=1 python -m pytest -q tests/test_region_presence_distributed.py
```

CUDA 检查在没有驱动的环境会跳过；分布式检查需显式启用。单元检查通过不代表正式分割指标已经提升。

2026-11-03 工程验收：122 项 CPU/回归检查通过；GPU 2 上的真实 VM-UNet AMP、恢复与导出检查，以及两进程 Gloo 检查共 2 项通过。另以独立三病例清单完成单患者两轮训练、第 1 轮后中断恢复和导出权重的单患者验证；导出前后的区域指标完全一致。清单仅取自原训练/验证集，未评价正式测试集。详见 [验收报告](../results/verification/region_presence_pipeline/verification_report.json)。
